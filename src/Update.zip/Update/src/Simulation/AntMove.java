package Simulation;
import java.util.Arrays;
import java.util.ArrayList;

public class AntMove{
    AntMove extends Event;

    private int Ant_move(int; Ant){

    }

    private int realize(){

    }

}


