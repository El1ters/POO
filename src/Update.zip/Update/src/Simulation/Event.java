package Simulation;
import java.util.Arrays;
import java.util.ArrayList;


public class Event {
    private int time_stamp;

    public void (time_stamp){

    }

    protected int realize(){

    }
}
