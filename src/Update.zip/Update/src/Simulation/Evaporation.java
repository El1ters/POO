package Simulation;
import java.util.Arrays;
import java.util.ArrayList;

public class Evaporation {
    Evaporation extends Event;

    private void Evap(){

    }

    private int realize(){

    }
}
