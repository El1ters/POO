package ACO;
import java.util.Arrays;
import java.util.ArrayList;

public class ACO {
    private int colony_size;
    private ArrayList<String> pheromones;
    private float alpha;
    private float beta;
    private float delta;
    private float gama;
    private float rho;
    private float eta;

    public int aco(){

    }

    public ArrayList<String> update_pheromones(pheromones){
        return pheromones;
    }

    public void get_pheromones(pheromones){

    }

    public int sum_weights(){

    }

}
