package ACO;
import java.util.Arrays;
import java.util.ArrayList;

public class best {

    private ArrayList<String> path;
    private int wsum;
}
