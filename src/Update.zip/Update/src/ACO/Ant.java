package ACO;
import java.util.Arrays;
import java.util.ArrayList;

public class Ant {

    private int n_nt;
    private ArrayList<String> curr_path;
    private int curr_node;
    private int next_node;

    public int next_node(curr_node){
        return next_node;
    }

    public ArrayList<String> update_path(curr_path){
        return curr_path;
    }

    public int update_current(curr_node){
        return curr_node;
    }

    public int calc_time(){

    }
}
